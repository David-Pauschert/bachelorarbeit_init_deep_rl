from debugpy import configure
import numpy as np
from scipy import stats
from typing import Any, Union, Dict
import gym
from stable_baselines3.common.vec_env import VecEnv
from stable_baselines3.common.callbacks import EvalCallback
from stable_baselines3.common.base_class import BaseAlgorithm
from stable_baselines3.common.policies import BasePolicy
from parameter_initialization_deep_rl.common.helpers import (
    plot_performance,
    create_folder,
    log_trial,
)
from stable_baselines3.common.logger import configure
import shutil
import uuid
from stable_baselines3 import DQN, PPO, A2C, SAC, TD3


def create_numpy_arr_from_logs(log_dirs):
    avg_returns = []
    for log_dir in log_dirs:
        logs = np.load(log_dir)
        results = logs["results"]
        avg_return = results.mean(axis=1)
        avg_returns.append(avg_return)
    avg_returns = np.array(avg_returns)
    n = avg_returns.shape[0]
    return avg_returns, n


def mean_confidence_intervals(avg_returns, n, confidence=0.95):
    AVG = avg_returns.mean(axis=0)
    STD = avg_returns.std(axis=0)
    H = STD * stats.t.ppf((1 + confidence) / 2., n-1)
    return AVG, H


def delete_folder(folder):
    shutil.rmtree(folder, ignore_errors=True)


def run_single_trial(
    env_train: Union[gym.Env, VecEnv],
    env_test: Union[gym.Env, VecEnv],
    log_dir: str,
    model_dir: str,
    algorithm: BaseAlgorithm,
    policy: BasePolicy,
    hyperparameter: Dict[str, Any],
    policy_kwargs: Dict[str, Any],
    seed: int,
    train_timesteps: int,
    n_eval_episodes: int,
    eval_freq: int,
    deterministic: bool,
    render: bool,
):

    trial_log_dir = create_folder(f"{log_dir}/{seed}")
    if model_dir is not None:
        trial_model_dir = create_folder(f"{model_dir}/{seed}")

    eval_callback = EvalCallback(
        env_test,
        best_model_save_path=model_dir,
        log_path=trial_log_dir,
        n_eval_episodes=n_eval_episodes,
        eval_freq=eval_freq,
        deterministic=deterministic,
        render=render
    )

    # Instantiate the model
    model = algorithm(
        policy=policy,
        env=env_train,
        policy_kwargs=policy_kwargs,
        seed=seed,
        verbose=1,
        tensorboard_log=f"{log_dir}/tensorboard/",
        **hyperparameter
    )

    # Train the model
    model.learn(
        total_timesteps=train_timesteps,
        callback=eval_callback,
    )

    log_folder = f"{trial_log_dir}/evaluations.npz"

    return log_folder


def create_sample(avg_return_per_eval_ep, n_last_episodes=None):
    lower_bound = np.maximum(
        0, avg_return_per_eval_ep.shape[1] - n_last_episodes) if n_last_episodes is not None else 0
    sample = np.mean(avg_return_per_eval_ep[:, lower_bound:], axis=1)
    return sample


def run_multiple_trials(
    env_train: Union[gym.Env, VecEnv],
    env_test: Union[gym.Env, VecEnv],
    algorithm: BaseAlgorithm,
    policy: BasePolicy,
    hyperparameter: Dict[str, Any],
    policy_kwargs: Dict[str, Any],
    num_trials: int = 20,
    train_timesteps: int = 5e4,
    n_eval_episodes: int = 10,
    eval_freq: int = 1000,
    deterministic: bool = True,
    model_dir: str = None,
    render: bool = False,
):
    uid = uuid.uuid1().__str__()
    log_dir = f"../logs/{uid}"
    log_dirs = []
    for seed in range(1, 1 + num_trials):
        log_folder = run_single_trial(
            env_train=env_train,
            env_test=env_test,
            log_dir=log_dir,
            model_dir=model_dir,
            algorithm=algorithm,
            policy=policy,
            hyperparameter=hyperparameter,
            policy_kwargs=policy_kwargs,
            seed=seed,
            train_timesteps=train_timesteps,
            n_eval_episodes=n_eval_episodes,
            eval_freq=eval_freq,
            deterministic=deterministic,
            render=render,
        )
        log_dirs.append(log_folder)

    avg_returns, n = create_numpy_arr_from_logs(log_dirs)

    sample = create_sample(avg_returns)

    # Save the performance score for the individual seeds
    np.savez(f"{log_dir}/avg_perf_across_seeds",
             sample=sample, policy_kwargs=[policy_kwargs])

    performance_score = np.average(sample)

    # Save the performance score, i.e., the averaged return across all seeds and evaluation periods, i.e., just one single number
    np.savez(f"{log_dir}/perf_score",
             perf_score=performance_score, policy_kwargs=[policy_kwargs])

    AVG, H = mean_confidence_intervals(avg_returns, n)

    # Save the average return and confidence intervals for all the individual evaluation trials averaged across all seeds
    np.savez(f"{log_dir}/avg_perf_eval_trials", avg=AVG,
             h=H, policy_kwargs=[policy_kwargs])

    split_env = str(env_test.env).split("<")
    # Log the performance and trial results as well as the configuration in the global_logging.csv file
    log_data = {
        "id": uid,
        "env": split_env[len(split_env) - 1].replace(">",""),
        "algo": algorithm.__name__,
        "policy": policy.__name__,
        "weight_init": policy_kwargs["weight_init"],
        "bias_init": policy_kwargs["bias_init"],
        "activation_fn": policy_kwargs["activation_fn"].__name__,
        "value_net_scaling": policy_kwargs["value_net_scaling"],
        "performance": performance_score,
    }
    if algorithm == DQN:
        log_data["value_net_depth"] = len(policy_kwargs["net_arch"])
        log_data["value_net_width"] = policy_kwargs["net_arch"][0]
    elif algorithm == PPO or algorithm == A2C:
        log_data["value_net_depth"] = len(policy_kwargs["net_arch"]["vf"])
        log_data["value_net_width"] = policy_kwargs["net_arch"]["vf"][0]
        log_data["policy_net_depth"] = len(policy_kwargs["net_arch"]["pi"])
        log_data["policy_net_width"] = policy_kwargs["net_arch"]["pi"][0]
    elif algorithm == TD3 or algorithm == SAC:
        log_data["value_net_depth"] = len(policy_kwargs["net_arch"]["qf"])
        log_data["value_net_width"] = policy_kwargs["net_arch"]["vf"][0]
        log_data["policy_net_depth"] = len(policy_kwargs["net_arch"]["pi"])
        log_data["policy_net_width"] = policy_kwargs["net_arch"]["pi"][0]

    log_trial(log_data)

    # Load performance averaged over different trials and plot it
    plot_performance(
        title="Performance",
        x=np.arange(eval_freq, train_timesteps + eval_freq, eval_freq),
        y=AVG,
        graph_label="average",
        x_label="Timesteps",
        y_label="Average Reward",
        h=None,
        save_path=log_dir
    )

    # Delete all the seed folder
    for seed in range(1, 1 + num_trials):
        delete_folder(f"{log_dir}/{seed}")

    # Delete tensorboard logs
    delete_folder(f"{log_dir}/tensorboard")

    return log_data

import random
from torch.nn.modules.activation import (
    Sigmoid,
    Tanh,
    ReLU,
    LeakyReLU,
    ELU,
)
import os
from matplotlib import pyplot as plt
import numpy as np
import csv
from stable_baselines3 import DQN, PPO, A2C, SAC, TD3
from stable_baselines3.common.base_class import BaseAlgorithm


def create_folder(path):
    if not os.path.exists(path):
        os.makedirs(path)
    return path


def plot_performance(title, x, y, graph_label, x_label, y_label, h=None, save_path=None):
    plt.plot(x, y, label=graph_label)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.title(title)
    if h is not None:
        plt.fill_between(x, y-h, y+h, alpha=.1)
    plt.legend()
    if save_path is not None:
        plt.savefig(f"{save_path}/{title}.png")


def sample_policy_config(algorithm: BaseAlgorithm):
    # Weight initialization method
    weight_init = random.choice(["lecun_normal", "lecun_uniform", "xavier_normal", "xavier_uniform",
                                "kaiming_normal", "kaiming_uniform", "orthogonal", "sparse", "nguyen_widrow"])
    # Bias initialization method
    if weight_init == "nguyen_widrow":
        bias_init = "nguyen_widrow"
    else:
        bias_init = random.choice(["random_uniform", "zeros", "0.01"])
    # Activation function
    activation_fn = random.choice([Sigmoid, Tanh, ReLU, LeakyReLU, ELU])
    # Network architecture
    if algorithm == DQN:
        value_network_depth = random.choice([1, 2, 4])
        value_network_width = random.choice([16, 32, 64, 128, 256, 512])
        net_arch = [value_network_width] * value_network_depth
    elif algorithm == PPO or algorithm == A2C:
        value_network_depth = random.choice([1, 2, 4])
        value_network_width = random.choice([16, 32, 64, 128, 256, 512])
        policy_network_depth = random.choice([1, 2, 4])
        policy_network_width = random.choice([16, 32, 64, 128, 256, 512])
        net_arch = [dict(
            vf=[value_network_width] * value_network_depth,
            pi=[policy_network_width] * policy_network_depth
        )]
    elif algorithm == TD3 or algorithm == SAC:
        value_network_depth = random.choice([1, 2, 4])
        value_network_width = random.choice([16, 32, 64, 128, 256, 512])
        policy_network_depth = random.choice([1, 2, 4])
        policy_network_width = random.choice([16, 32, 64, 128, 256, 512])
        net_arch = dict(
            qf=[value_network_width] * value_network_depth,
            pi=[policy_network_width] * policy_network_depth
        )
    # Scaling of the last layer of the policy network
    policy_net_scaling = 0 if algorithm == DQN else random.choice(
        [0.001, 0.01, 0.1, 1])
    # Scaling of the last layer of the value network
    value_net_scaling = random.choice([0.001, 0.01, 0.1, 1])
    # Wrap config in a dictionary
    policy_kwargs = {
        "weight_init": weight_init,
        "bias_init": bias_init,
        "activation_fn": activation_fn,
        "net_arch": net_arch,
        "policy_net_scaling": policy_net_scaling,
        "value_net_scaling": value_net_scaling,
    }
    return policy_kwargs

# Method to save trial data in CSV


def log_trial(log_data: dict):
    path = "../global_logging.csv"

    with open(path, "a", newline="") as f:
        fieldnames = ["id", "env", "algo", "policy", "weight_init", "bias_init", "activation_fn",
                      "policy_net_depth", "policy_net_width", "value_net_depth", "value_net_width", "policy_net_scaling", "value_net_scaling", "performance"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writerow(log_data)

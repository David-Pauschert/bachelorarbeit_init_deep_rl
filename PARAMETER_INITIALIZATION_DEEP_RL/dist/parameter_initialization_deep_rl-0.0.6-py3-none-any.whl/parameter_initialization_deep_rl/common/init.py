import math
from torch import nn
from torch import Tensor
import torch as th
import numpy as np


def init_weights(self, module: nn.Module, weight_init: str = "xavier_normal", gain: float = 1.) -> None:
    if(weight_init == "constant"):
        nn.init.constant_(module.weight, gain * 1.)
    if(weight_init == "lecun_normal"):
        lecun_normal_(module.weight, gain=gain)
    if(weight_init == "lecun_uniform"):
        lecun_uniform_(module.weight, gain=gain)
    if(weight_init == "xavier_normal"):
        nn.init.xavier_normal_(module.weight, gain=gain)
    if(weight_init == "xavier_uniform"):
        nn.init.xavier_uniform_(module.weight, gain=gain)
    if(weight_init == "kaiming_normal"):
        kaiming_normal_(module.weight, gain=gain)
    if(weight_init == "kaiming_uniform"):
        kaiming_uniform_(module.weight, gain=gain)
    if(weight_init == "orthogonal"):
        nn.init.orthogonal_(module.weight, gain=gain)
    if(weight_init == "sparse"):
        nn.init.sparse_(module.weight, 0.2)
    if(weight_init == "nguyen_widrow"):
        nguyen_widrow_(module.weight, module.bias, gain=gain)
    #print(module._get_name(), module.weight.size(), module.weight)


def init_bias(self, module: nn.Module, fan_in, bias_init: str = "lecun_uniform") -> None:
    if(bias_init == "random_uniform"):
        random_uniform(module.bias, fan_in=fan_in)
    if(bias_init == "zeros"):
        nn.init.zeros_(module.bias)
    if(bias_init == "0.01"):
        nn.init.constant_(module.bias, 0.01)
    if(bias_init == "nguyen_widrow"):
        pass
    #print(module.bias.size(), module.bias)


def lecun_normal_(tensor: Tensor, gain: float = 1.) -> Tensor:
    fan_in, fan_out = nn.init._calculate_fan_in_and_fan_out(tensor)
    std = gain * math.sqrt(1.0 / float(fan_in))
    return nn.init._no_grad_normal_(tensor, 0., std)


def lecun_uniform_(tensor: Tensor, gain: float = 1.) -> Tensor:
    fan_in, fan_out = nn.init._calculate_fan_in_and_fan_out(tensor)
    std = gain * math.sqrt(1.0 / float(fan_in))
    # Calculate uniform bounds from standard deviation
    a = math.sqrt(3.0) * std
    return nn.init._no_grad_uniform_(tensor, -a, a)


def random_uniform(tensor: Tensor, fan_in, gain: float = 1.):
    a = math.sqrt(1 / float(fan_in))
    return nn.init._no_grad_uniform_(tensor, -a, a)


def nguyen_widrow_(weight: Tensor, bias: Tensor, gain: float = 1.) -> Tensor:
    W = weight
    fan_in, fan_out = nn.init._calculate_fan_in_and_fan_out(weight)
    beta = 0.7 * (fan_out**(1 / fan_in))
    W_norm_vec = th.linalg.norm(W, dim=1)
    W_norm = th.transpose(W_norm_vec.repeat(fan_in, 1), 0, 1)
    W = th.mul(th.div(W, W_norm), beta)
    with th.no_grad():
        weight = W
    W_norm_2d = th.transpose(W_norm_vec.repeat(2, 1), 0, 1)
    a = np.ones(shape=(fan_out, 2))
    np.ndarray.fill(a[:, 0], -1)
    ranges = W_norm_2d.cpu().detach().numpy() * a
    b = np.random.uniform(
        low=ranges[:, 0], high=ranges[:, 1], size=(1, ranges.shape[0]))
    with th.no_grad():
        bias = b
    return weight, bias


def kaiming_normal_(tensor: Tensor, mode: str = "fan_in", gain: float = 1.):
    fan = nn.init._calculate_correct_fan(tensor, mode)
    std = gain * math.sqrt(2 / fan)
    with th.no_grad():
        return tensor.normal_(0, std)


def kaiming_uniform_(tensor: Tensor, mode: str = "fan_in", gain: float = 1.):
    fan = nn.init._calculate_correct_fan(tensor, mode)
    std = gain * math.sqrt(2 / fan)
    # Calculate uniform bounds from standard deviation
    bound = math.sqrt(3.0) * std
    with th.no_grad():
        return tensor.uniform_(-bound, bound)

def printText():
    print("This text is printed")
